<?php $data = $this->type_data; ?>
<textarea class="inputbox inv_txtarea" cols="30" rows= "15"  name="type_desc"><?php echo stripslashes($data->widget) ;?></textarea>
