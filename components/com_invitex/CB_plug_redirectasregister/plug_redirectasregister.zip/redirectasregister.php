<?php
/**
* Newsletter Tab Class for handling the CB tab api
* @version $Id: yanc.php 1186 2010-10-03 16:52:26Z beat $
* @package Community Builder
* @subpackage yanc.php
* @author Beat
* @copyright (C) JoomlaJoe and Beat, www.joomlapolis.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

global $_PLUGINS;
$_PLUGINS->registerFunction( 'onAfterUserRegistrationMailsSent', 'redirectAsRegister' );


function redirectAsRegister($user)
{
		$mainframe=JFactory::getApplication();
    	if($mainframe->isAdmin()){
    	   return;
   		}
		$filename = JPATH_SITE . DS .'components'. DS .'com_invitex'.DS.'helper.php';
		$itemid = 0;
				if(JFile::exists($filename)){
				require($filename);
				$itemid	=	cominvitexHelper::getitemid('index.php?option=com_invitex&view=invites');
				$invitex_settings	= cominvitexHelper::getconfigData();

				if($invitex_settings["invitation_during_reg"])
				{
					if(!(isset($_COOKIE['invitex_visited']) && $_COOKIE['invitex_visited']!=''))
					{
						$expire = time()+3600*24*30;
						setcookie("invitex_visited", '1', $expire, "/");
						$msg="Registration complete! Invite your friends and start building your network!";
						$mainframe->redirect(JRoute::_('index.php?option=com_invitex&view=invites&Itemid='.$itemid,false), $msg);
					}
				}
		}
}

